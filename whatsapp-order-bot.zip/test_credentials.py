"""Verify your WhatsApp Cloud API credentials.

Usage:
    python test_credentials.py                 # checks token + phone number ID only (sends nothing)
    python test_credentials.py --send          # also sends a hello_world template to TEST_RECIPIENT
    python test_credentials.py --send --text   # also sends a free-text + button message
                                               #   (works only if TEST_RECIPIENT messaged you in the last 24h)
"""
import argparse
import os
import sys

from dotenv import load_dotenv

load_dotenv()
from whatsapp_client import WhatsApp, WhatsAppError  # noqa: E402


def need(*names):
    missing = [n for n in names if not os.getenv(n)]
    if missing:
        sys.exit(f"Missing in .env: {', '.join(missing)}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--send", action="store_true", help="send the hello_world template")
    ap.add_argument("--text", action="store_true", help="also send text + buttons (needs open 24h window)")
    args = ap.parse_args()

    need("WHATSAPP_TOKEN", "WHATSAPP_PHONE_NUMBER_ID")
    wa = WhatsApp()

    print("1) Checking token + phone number ID ...")
    try:
        info = wa.phone_info()
        print("   OK ->", info)
    except WhatsAppError as e:
        sys.exit(f"   FAILED: {e}\n   Hints: expired temporary token? wrong Phone number ID? "
                 "token missing whatsapp_business_messaging permission?")

    if not args.send:
        print("\nCredentials work. Re-run with --send to deliver a real test message.")
        return

    need("TEST_RECIPIENT")
    to = os.environ["TEST_RECIPIENT"].lstrip("+")
    print(f"\n2) Sending hello_world template to {to} ...")
    try:
        print("   OK ->", wa.send_template(to, "hello_world", "en_US"))
    except WhatsAppError as e:
        sys.exit(f"   FAILED: {e}")

    if args.text:
        print("\n3) Sending free-text + interactive buttons ...")
        try:
            wa.send_text(to, "Test message from your order bot ✅")
            wa.send_buttons(to, "Do the buttons render?", [("yes", "Yes"), ("no", "No")])
            print("   OK")
        except WhatsAppError as e:
            sys.exit(f"   FAILED: {e}\n   (Error 131047 = reply to the test number from {to} first, "
                     "then retry within 24h.)")
    print("\nAll good.")


if __name__ == "__main__":
    main()
