# WhatsApp Order Bot (Cloud API)

Customers order on WhatsApp (buttons + lists), the bot asks for items, delivery day, time slot and address,
alerts the shopkeeper with Accept/Reject buttons, and the shopkeeper gets a monthly report
(on WhatsApp via `report`, and on a web page at `/report`).

## 1. Docs you need (official)
- Get started: https://developers.facebook.com/documentation/business-messaging/whatsapp/get-started
- Send messages / interactive buttons & lists / templates / webhooks: same site, "Business messaging > WhatsApp"
- Note: Meta's own Node/Python helper SDKs are archived, so this project calls the official Graph API directly
  with `requests` (`whatsapp_client.py`). Endpoint: `POST https://graph.facebook.com/{version}/{PHONE_NUMBER_ID}/messages`.

## 2. Create API credentials
1. Register at https://developers.facebook.com and create a **Business** app, add the **WhatsApp** product.
2. WhatsApp > **API Setup**: Meta gives a free **test number**. Note the **Phone number ID** and **WhatsApp Business Account ID**.
   Add your own phone (and the shopkeeper's) under "To" as allowed recipients and verify with the OTP.
3. The "Generate access token" button gives a **temporary token (~24h)**. Fine for the first test.
4. For a **permanent token**: business.facebook.com > Settings > Users > **System users** > add a system user (Admin),
   assign your app + WhatsApp account, generate a token with `whatsapp_business_messaging` and
   `whatsapp_business_management`, no expiry. Put it in `WHATSAPP_TOKEN`.
5. App **Settings > Basic > App secret** -> `APP_SECRET` (used to verify webhook signatures).
6. Copy `.env.example` to `.env` and fill it in.

## 3. Test the credentials
```bash
pip install -r requirements.txt
python test_credentials.py                  # validates token + phone number ID, sends nothing
python test_credentials.py --send           # sends the hello_world template to TEST_RECIPIENT
python test_credentials.py --send --text    # also text + buttons (recipient must have messaged you in the last 24h)
```
No Meta account yet? `python simulate.py` runs the whole conversation offline with a fake client.

## 4. Run the chatbot
```bash
python bot.py                       # local, port 5000
ngrok http 5000                     # public HTTPS URL for Meta (or deploy with: gunicorn bot:app)
```
In Meta dashboard: WhatsApp > **Configuration** > Webhook: Callback URL `https://<public-url>/webhook`,
Verify token = `VERIFY_TOKEN` from `.env`, then subscribe to the **messages** field.

### Customer experience
`hi` -> buttons (New order / My orders / Help) -> type items -> Today/Tomorrow/Another date -> time-slot list ->
address -> summary with Confirm/Cancel -> order number. `cancel` works at any step.

### Shopkeeper
- Every new order arrives with **Accept / Reject** buttons; the customer is notified automatically.
- Texts: `orders`, `accept 12`, `reject 12`, `done 12`, `report`, `report 2026-09`, `commands`.
- Web report: `https://<public-url>/report?key=<ADMIN_KEY>` (month picker included).

## Important WhatsApp rules
- **24-hour window:** free-form/interactive messages only reach a person who messaged the bot within the last 24h.
  The shopkeeper must message the bot number at least once a day, or create an approved **template** with one
  body variable and set `SHOPKEEPER_TEMPLATE_NAME` so alerts still go through.
- Test numbers only message verified recipients. For real customers, add your own business phone number and complete
  Meta business verification.
- Limits: max 3 reply buttons (20-char titles), list rows max 10 (24-char titles).
- Data is in SQLite (`orders.db`). Use a persistent disk or switch to Postgres when deploying.
