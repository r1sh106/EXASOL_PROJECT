"""Thin client for the official WhatsApp Cloud API (Meta Graph API).

Docs: https://developers.facebook.com/documentation/business-messaging/whatsapp/
"""
import os
import requests


class WhatsAppError(Exception):
    def __init__(self, status, body):
        self.status = status
        self.body = body
        err = (body or {}).get("error", {}) if isinstance(body, dict) else {}
        self.code = err.get("code")
        super().__init__(f"HTTP {status}: {err.get('message', body)} (code={self.code})")


class WhatsApp:
    def __init__(self, token=None, phone_number_id=None, version=None):
        self.token = token or os.environ["WHATSAPP_TOKEN"]
        self.phone_id = phone_number_id or os.environ["WHATSAPP_PHONE_NUMBER_ID"]
        self.version = version or os.getenv("WHATSAPP_API_VERSION", "v23.0")
        self.base = f"https://graph.facebook.com/{self.version}"

    # ---- low level ----
    def _req(self, method, path, **kw):
        r = requests.request(
            method,
            f"{self.base}/{path}",
            headers={"Authorization": f"Bearer {self.token}"},
            timeout=20,
            **kw,
        )
        try:
            body = r.json()
        except ValueError:
            body = {"raw": r.text}
        if not r.ok:
            raise WhatsAppError(r.status_code, body)
        return body

    def _send(self, to, payload):
        payload = {"messaging_product": "whatsapp", "recipient_type": "individual", "to": to, **payload}
        return self._req("POST", f"{self.phone_id}/messages", json=payload)

    # ---- account checks ----
    def phone_info(self):
        return self._req(
            "GET",
            self.phone_id,
            params={"fields": "display_phone_number,verified_name,quality_rating,code_verification_status"},
        )

    # ---- messages ----
    def send_text(self, to, text):
        return self._send(to, {"type": "text", "text": {"body": text, "preview_url": False}})

    def send_buttons(self, to, body, buttons, header=None, footer=None):
        """buttons: list of (id, title). WhatsApp allows max 3; title max 20 chars."""
        assert 1 <= len(buttons) <= 3
        inter = {
            "type": "button",
            "body": {"text": body},
            "action": {
                "buttons": [{"type": "reply", "reply": {"id": i, "title": t[:20]}} for i, t in buttons]
            },
        }
        if header:
            inter["header"] = {"type": "text", "text": header}
        if footer:
            inter["footer"] = {"text": footer}
        return self._send(to, {"type": "interactive", "interactive": inter})

    def send_list(self, to, body, button_text, rows, section_title="Options", footer=None):
        """rows: list of (id, title, description). Max 10 rows; title max 24 chars."""
        inter = {
            "type": "list",
            "body": {"text": body},
            "action": {
                "button": button_text[:20],
                "sections": [
                    {
                        "title": section_title[:24],
                        "rows": [
                            {"id": i, "title": t[:24], **({"description": d[:72]} if d else {})}
                            for i, t, d in rows
                        ],
                    }
                ],
            },
        }
        if footer:
            inter["footer"] = {"text": footer}
        return self._send(to, {"type": "interactive", "interactive": inter})

    def send_template(self, to, name, lang="en", body_params=None):
        tpl = {"name": name, "language": {"code": lang}}
        if body_params:
            tpl["components"] = [
                {"type": "body", "parameters": [{"type": "text", "text": p} for p in body_params]}
            ]
        return self._send(to, {"type": "template", "template": tpl})

    def mark_read(self, message_id):
        return self._req(
            "POST",
            f"{self.phone_id}/messages",
            json={"messaging_product": "whatsapp", "status": "read", "message_id": message_id},
        )
