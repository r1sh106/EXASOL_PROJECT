"""SQLite storage: conversation sessions + orders + monthly report queries."""
import json
import os
import sqlite3
from datetime import datetime, timedelta, timezone
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

try:
    TZ = ZoneInfo(os.getenv("TZ", "Asia/Kolkata"))
except ZoneInfoNotFoundError:  # no tz database (pip install tzdata fixes this)
    print("[WARN] timezone database missing; using fixed UTC+05:30. Run: pip install tzdata")
    TZ = timezone(timedelta(hours=5, minutes=30))


def now():
    return datetime.now(TZ)


def conn():
    c = sqlite3.connect(os.getenv("DB_PATH", "orders.db"))
    c.row_factory = sqlite3.Row
    return c


def init():
    with conn() as c:
        c.executescript(
            """
            CREATE TABLE IF NOT EXISTS sessions(
                phone TEXT PRIMARY KEY, state TEXT, data TEXT, updated TEXT);
            CREATE TABLE IF NOT EXISTS orders(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                phone TEXT, name TEXT, items TEXT,
                delivery_date TEXT, delivery_slot TEXT, address TEXT, notes TEXT,
                status TEXT DEFAULT 'new', created_at TEXT);
            CREATE TABLE IF NOT EXISTS seen(msg_id TEXT PRIMARY KEY);
            """
        )


# ---- sessions ----
def get_session(phone):
    with conn() as c:
        r = c.execute("SELECT * FROM sessions WHERE phone=?", (phone,)).fetchone()
    if not r:
        return {"state": "NEW", "data": {}}
    return {"state": r["state"], "data": json.loads(r["data"] or "{}")}


def save_session(phone, state, data):
    with conn() as c:
        c.execute(
            "INSERT INTO sessions(phone,state,data,updated) VALUES(?,?,?,?) "
            "ON CONFLICT(phone) DO UPDATE SET state=excluded.state,data=excluded.data,updated=excluded.updated",
            (phone, state, json.dumps(data), now().isoformat()),
        )


def already_seen(msg_id):
    """Meta may redeliver webhooks; returns True if we've processed this message."""
    with conn() as c:
        try:
            c.execute("INSERT INTO seen(msg_id) VALUES(?)", (msg_id,))
            return False
        except sqlite3.IntegrityError:
            return True


# ---- orders ----
def create_order(phone, name, d):
    with conn() as c:
        cur = c.execute(
            "INSERT INTO orders(phone,name,items,delivery_date,delivery_slot,address,notes,created_at) "
            "VALUES(?,?,?,?,?,?,?,?)",
            (phone, name, d["items"], d["date"], d["slot"], d["address"], d.get("notes", ""), now().isoformat()),
        )
        return cur.lastrowid


def get_order(oid):
    with conn() as c:
        return c.execute("SELECT * FROM orders WHERE id=?", (oid,)).fetchone()


def set_status(oid, status):
    with conn() as c:
        c.execute("UPDATE orders SET status=? WHERE id=?", (status, oid))


def customer_orders(phone, limit=5):
    with conn() as c:
        return c.execute(
            "SELECT * FROM orders WHERE phone=? ORDER BY id DESC LIMIT ?", (phone, limit)
        ).fetchall()


def open_orders():
    with conn() as c:
        return c.execute(
            "SELECT * FROM orders WHERE status IN ('new','accepted') ORDER BY delivery_date, id"
        ).fetchall()


# ---- reporting ----
def monthly_report(month=None):
    """month = 'YYYY-MM' (defaults to current month in shop timezone)."""
    month = month or now().strftime("%Y-%m")
    like = month + "%"
    with conn() as c:
        q = lambda sql, *a: c.execute(sql, a).fetchall()
        total = q("SELECT COUNT(*) n FROM orders WHERE created_at LIKE ?", like)[0]["n"]
        customers = q("SELECT COUNT(DISTINCT phone) n FROM orders WHERE created_at LIKE ?", like)[0]["n"]
        by_status = q("SELECT status, COUNT(*) n FROM orders WHERE created_at LIKE ? GROUP BY status", like)
        by_day = q(
            "SELECT substr(created_at,1,10) d, COUNT(*) n FROM orders WHERE created_at LIKE ? GROUP BY d ORDER BY d",
            like,
        )
        by_slot = q(
            "SELECT delivery_slot s, COUNT(*) n FROM orders WHERE created_at LIKE ? GROUP BY s ORDER BY n DESC",
            like,
        )
        top = q(
            "SELECT name, phone, COUNT(*) n FROM orders WHERE created_at LIKE ? GROUP BY phone ORDER BY n DESC LIMIT 5",
            like,
        )
    return {
        "month": month,
        "total": total,
        "customers": customers,
        "by_status": {r["status"]: r["n"] for r in by_status},
        "by_day": [(r["d"], r["n"]) for r in by_day],
        "by_slot": [(r["s"], r["n"]) for r in by_slot],
        "top_customers": [(r["name"] or r["phone"], r["phone"], r["n"]) for r in top],
    }


def report_text(rep):
    delivered = rep["by_status"].get("delivered", 0)
    lines = [
        f"*Monthly report: {rep['month']}*",
        f"Orders: {rep['total']}  |  Customers: {rep['customers']}",
        f"Delivered: {delivered}  |  New: {rep['by_status'].get('new', 0)}  |  "
        f"Accepted: {rep['by_status'].get('accepted', 0)}  |  Rejected: {rep['by_status'].get('rejected', 0)}",
    ]
    if rep["by_slot"]:
        lines.append("Popular slots: " + ", ".join(f"{s} ({n})" for s, n in rep["by_slot"][:3]))
    if rep["top_customers"]:
        lines.append("Top customers: " + ", ".join(f"{n} ({c})" for n, _, c in rep["top_customers"][:3]))
    return "\n".join(lines)
