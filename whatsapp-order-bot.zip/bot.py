"""WhatsApp order-taking bot.

Customer flow : menu -> items -> delivery day -> delivery slot -> address -> confirm
Shopkeeper    : gets an alert per order (Accept/Reject buttons), can text "orders", "report", "done 12"
Web report    : /report?key=ADMIN_KEY[&month=YYYY-MM]

Run:  python bot.py          (dev)      |   gunicorn bot:app   (prod)
"""
import hashlib
import hmac
import html
import os
from datetime import timedelta

from dotenv import load_dotenv
from flask import Flask, abort, request

load_dotenv()
import db  # noqa: E402  (after load_dotenv so DB_PATH/TZ are read)
from whatsapp_client import WhatsApp, WhatsAppError  # noqa: E402

SHOP = os.getenv("SHOP_NAME", "Our Shop")
SHOPKEEPER = os.getenv("SHOPKEEPER_PHONE", "").lstrip("+")
SLOTS = [
    ("slot_morning", "Morning", "9 AM - 12 PM"),
    ("slot_afternoon", "Afternoon", "12 PM - 4 PM"),
    ("slot_evening", "Evening", "4 PM - 8 PM"),
    ("slot_asap", "As soon as possible", "Within ~1 hour"),
]
SLOT_LABEL = {i: f"{t} ({d})" for i, t, d in SLOTS}


# --------------------------------------------------------------------------
# Conversation logic (pure function of wa-client + input, so it is testable)
# --------------------------------------------------------------------------
def send_menu(wa, phone, name):
    wa.send_buttons(
        phone,
        f"Hi {name or 'there'}! 👋 Welcome to *{SHOP}*.\nWhat would you like to do?",
        [("new_order", "🛒 New order"), ("my_orders", "📦 My orders"), ("help", "ℹ️ Help")],
    )


def handle(wa, phone, name, text=None, reply_id=None):
    """Process one inbound message from `phone`."""
    if SHOPKEEPER and phone == SHOPKEEPER:
        if handle_shopkeeper(wa, phone, text, reply_id):
            return

    s = db.get_session(phone)
    state, data = s["state"], s["data"]
    inp = (text or "").strip()
    low = inp.lower()
    rid = reply_id or ""

    # Global commands work in any state
    if low in {"hi", "hello", "hey", "menu", "start", "cancel", "restart"} or rid == "cancel":
        db.save_session(phone, "MENU", {})
        if low == "cancel" or rid == "cancel":
            wa.send_text(phone, "Order cancelled. Send *hi* any time to start again.")
        else:
            send_menu(wa, phone, name)
        return

    if rid == "help" or low == "help":
        wa.send_text(
            phone,
            f"*{SHOP}* order bot\n• Send *hi* for the menu\n• Send *cancel* to stop an order\n"
            "We'll confirm your order here once the shop accepts it.",
        )
        return

    if rid == "my_orders" or low in {"orders", "my orders"}:
        rows = db.customer_orders(phone)
        if not rows:
            wa.send_text(phone, "You have no orders yet. Send *hi* to place one.")
        else:
            lines = [
                f"#{r['id']} · {r['delivery_date']} {r['delivery_slot']} · *{r['status']}*\n   {r['items'][:60]}"
                for r in rows
            ]
            wa.send_text(phone, "*Your recent orders*\n\n" + "\n\n".join(lines))
        return

    if rid == "new_order" or (state in {"NEW", "MENU"} and low in {"order", "new order"}):
        db.save_session(phone, "ITEMS", {})
        wa.send_text(
            phone,
            "Great! 🛒 Please type your order, items with quantities.\n"
            "_Example: 2 kg rice, 1 L milk, 6 eggs_",
        )
        return

    # ---- order wizard ----
    if state == "ITEMS" and inp:
        data["items"] = inp
        db.save_session(phone, "DAY", data)
        wa.send_buttons(
            phone,
            "📅 When should we deliver?",
            [("day_today", "Today"), ("day_tomorrow", "Tomorrow"), ("day_other", "Another date")],
        )
        return

    if state == "DAY":
        today = db.now().date()
        if rid == "day_today":
            data["date"] = today.isoformat()
        elif rid == "day_tomorrow":
            data["date"] = (today + timedelta(days=1)).isoformat()
        elif rid == "day_other":
            db.save_session(phone, "DATE_TEXT", data)
            wa.send_text(phone, "Please type the delivery date as *DD-MM-YYYY* (e.g. 05-11-2026).")
            return
        else:
            wa.send_text(phone, "Please tap one of the buttons above, or send *cancel*.")
            return
        ask_slot(wa, phone, data)
        return

    if state == "DATE_TEXT":
        from datetime import datetime

        try:
            d = datetime.strptime(inp, "%d-%m-%Y").date()
        except ValueError:
            wa.send_text(phone, "Sorry, I couldn't read that. Use *DD-MM-YYYY*, e.g. 05-11-2026.")
            return
        if d < db.now().date():
            wa.send_text(phone, "That date is in the past. Please send a future date.")
            return
        data["date"] = d.isoformat()
        ask_slot(wa, phone, data)
        return

    if state == "SLOT":
        if rid in SLOT_LABEL:
            data["slot"] = SLOT_LABEL[rid]
            db.save_session(phone, "ADDRESS", data)
            wa.send_text(phone, "📍 Please type your *delivery address* (include landmark / phone if needed).")
        else:
            wa.send_text(phone, "Please pick a time from the list, or send *cancel*.")
        return

    if state == "ADDRESS" and inp:
        data["address"] = inp
        db.save_session(phone, "CONFIRM", data)
        wa.send_buttons(
            phone,
            "*Please confirm your order*\n\n"
            f"🛒 {data['items']}\n📅 {data['date']}\n⏰ {data['slot']}\n📍 {data['address']}",
            [("confirm", "✅ Confirm"), ("cancel", "❌ Cancel")],
        )
        return

    if state == "CONFIRM":
        if rid == "confirm":
            oid = db.create_order(phone, name, data)
            db.save_session(phone, "MENU", {})
            wa.send_text(
                phone,
                f"✅ Order *#{oid}* placed! We've notified the shop and will confirm shortly.\n"
                "Send *hi* to place another order.",
            )
            notify_shopkeeper(wa, oid)
        else:
            wa.send_text(phone, "Tap *Confirm* to place the order, or *Cancel* to stop.")
        return

    # Fallback
    send_menu(wa, phone, name)
    db.save_session(phone, "MENU", {})


def ask_slot(wa, phone, data):
    db.save_session(phone, "SLOT", data)
    wa.send_list(
        phone,
        f"⏰ Pick a delivery time for {data['date']}:",
        "Choose time",
        SLOTS,
        section_title="Delivery slots",
    )


# --------------------------------------------------------------------------
# Shopkeeper side
# --------------------------------------------------------------------------
def order_summary(o):
    return (
        f"🆕 *New order #{o['id']}*\n"
        f"👤 {o['name'] or 'Customer'} (+{o['phone']})\n"
        f"🛒 {o['items']}\n📅 {o['delivery_date']}  ⏰ {o['delivery_slot']}\n📍 {o['address']}"
    )


def notify_shopkeeper(wa, order_id):
    if not SHOPKEEPER:
        print("SHOPKEEPER_PHONE not set; skipping notification")
        return
    o = db.get_order(order_id)
    try:
        wa.send_buttons(
            SHOPKEEPER,
            order_summary(o),
            [(f"accept_{order_id}", "✅ Accept"), (f"reject_{order_id}", "❌ Reject")],
        )
    except WhatsAppError as e:
        # 131047 = 24h customer-service window closed -> business-initiated messages must be templates
        tpl = os.getenv("SHOPKEEPER_TEMPLATE_NAME")
        if tpl:
            wa.send_template(
                SHOPKEEPER, tpl, os.getenv("SHOPKEEPER_TEMPLATE_LANG", "en"),
                [order_summary(o).replace("\n", " | ")],
            )
        else:
            print(f"[WARN] Could not alert shopkeeper ({e}). Message the bot from the shopkeeper "
                  "number every <24h or configure SHOPKEEPER_TEMPLATE_NAME.")


def handle_shopkeeper(wa, phone, text, reply_id):
    """Returns True if the message was a shopkeeper command and has been handled."""
    low = (text or "").strip().lower()
    rid = reply_id or ""

    for verb, status, cust_msg in (
        ("accept", "accepted", "✅ Your order *#{id}* has been accepted and will arrive on {when}."),
        ("reject", "rejected", "😔 Sorry, order *#{id}* couldn't be accepted. Please contact the shop."),
        ("done", "delivered", "📦 Order *#{id}* has been delivered. Thank you for shopping with us!"),
    ):
        oid = None
        if rid.startswith(verb + "_"):
            oid = rid.split("_", 1)[1]
        elif low.startswith(verb + " "):
            oid = low.split(" ", 1)[1].lstrip("#")
        if oid and oid.isdigit():
            o = db.get_order(int(oid))
            if not o:
                wa.send_text(phone, f"Order #{oid} not found.")
                return True
            db.set_status(o["id"], status)
            wa.send_text(phone, f"Order #{o['id']} marked *{status}*.")
            wa.send_text(
                o["phone"],
                cust_msg.format(id=o["id"], when=f"{o['delivery_date']}, {o['delivery_slot']}"),
            )
            return True

    if low.startswith("report"):
        parts = low.split()
        month = parts[1] if len(parts) > 1 else None  # "report 2026-10"
        wa.send_text(phone, db.report_text(db.monthly_report(month)))
        return True

    if low in {"orders", "pending"}:
        rows = db.open_orders()
        if not rows:
            wa.send_text(phone, "No open orders 🎉")
        else:
            wa.send_text(
                phone,
                "*Open orders*\n\n"
                + "\n\n".join(
                    f"#{r['id']} · {r['delivery_date']} {r['delivery_slot']} · *{r['status']}*\n"
                    f"   {r['name'] or r['phone']}: {r['items'][:60]}"
                    for r in rows
                ),
            )
        return True

    if low in {"shop", "admin", "commands"}:
        wa.send_text(
            phone,
            "*Shopkeeper commands*\n• orders — open orders\n• accept 12 / reject 12 / done 12\n"
            "• report — this month's summary\n• report 2026-09 — a past month\n"
            "(To place a test order as a customer, use a different number.)",
        )
        return True
    return False  # fall through: shopkeeper can also use the customer flow


# --------------------------------------------------------------------------
# Flask app: webhook + report page
# --------------------------------------------------------------------------
app = Flask(__name__)
db.init()
_wa = None


def wa_client():
    global _wa
    if _wa is None:
        _wa = WhatsApp()
    return _wa


@app.get("/webhook")
def verify():
    if (
        request.args.get("hub.mode") == "subscribe"
        and request.args.get("hub.verify_token") == os.getenv("VERIFY_TOKEN")
    ):
        return request.args.get("hub.challenge", ""), 200
    abort(403)


def valid_signature(raw: bytes) -> bool:
    secret = os.getenv("APP_SECRET")
    if not secret:
        print("[WARN] APP_SECRET not set: webhook signatures are NOT being verified")
        return True
    sent = request.headers.get("X-Hub-Signature-256", "")
    digest = "sha256=" + hmac.new(secret.encode(), raw, hashlib.sha256).hexdigest()
    return hmac.compare_digest(sent, digest)


@app.post("/webhook")
def webhook():
    if not valid_signature(request.get_data()):
        abort(403)
    payload = request.get_json(silent=True) or {}
    for entry in payload.get("entry", []):
        for change in entry.get("changes", []):
            v = change.get("value", {})
            names = {c["wa_id"]: c.get("profile", {}).get("name") for c in v.get("contacts", [])}
            for m in v.get("messages", []):
                if db.already_seen(m["id"]):
                    continue
                phone = m["from"]
                text = reply_id = None
                if m["type"] == "text":
                    text = m["text"]["body"]
                elif m["type"] == "interactive":
                    it = m["interactive"]
                    reply_id = (it.get("button_reply") or it.get("list_reply") or {}).get("id")
                try:
                    wa_client().mark_read(m["id"])
                    handle(wa_client(), phone, names.get(phone), text, reply_id)
                except Exception as e:  # never return 5xx, Meta would keep retrying
                    print(f"[ERROR] handling message from {phone}: {e!r}")
    return "ok", 200


@app.get("/report")
def report_page():
    admin_key = os.getenv("ADMIN_KEY")
    if not admin_key or not hmac.compare_digest(request.args.get("key", ""), admin_key):
        abort(403)
    rep = db.monthly_report(request.args.get("month"))
    e = html.escape
    mx = max([n for _, n in rep["by_day"]] or [1])
    bars = "".join(
        f"<div class=r><span>{e(d[5:])}</span><i style='width:{n / mx * 100:.0f}%'></i><b>{n}</b></div>"
        for d, n in rep["by_day"]
    ) or "<p class=m>No orders yet this month.</p>"
    statuses = "".join(
        f"<div class=c><b>{rep['by_status'].get(s, 0)}</b><span>{s}</span></div>"
        for s in ("new", "accepted", "delivered", "rejected")
    )
    slots = "".join(f"<li>{e(s or '-')} <b>{n}</b></li>" for s, n in rep["by_slot"]) or "<li class=m>-</li>"
    top = "".join(f"<li>{e(str(n))} <span class=m>+{e(p)}</span> <b>{c}</b></li>" for n, p, c in rep["top_customers"]) or "<li class=m>-</li>"
    return f"""<!doctype html><meta charset=utf-8><meta name=viewport content="width=device-width,initial-scale=1">
<title>{e(SHOP)} · {e(rep['month'])}</title>
<style>
:root{{--bg:#f6f7f9;--card:#fff;--ink:#1c2430;--mut:#6b7788;--acc:#128c7e}}
@media(prefers-color-scheme:dark){{:root{{--bg:#12161c;--card:#1b222b;--ink:#e8edf3;--mut:#93a0b1;--acc:#25d366}}}}
body{{margin:0;background:var(--bg);color:var(--ink);font:15px system-ui,sans-serif;padding:16px}}
main{{max-width:760px;margin:auto}} h1{{font-size:20px;margin:0 0 4px}} .m{{color:var(--mut)}}
.card{{background:var(--card);border-radius:12px;padding:16px;margin:12px 0}}
.grid{{display:grid;grid-template-columns:repeat(auto-fit,minmax(130px,1fr));gap:10px}}
.c{{background:var(--card);border-radius:12px;padding:14px;text-align:center}} .c b{{display:block;font-size:26px;color:var(--acc)}}
.r{{display:flex;align-items:center;gap:8px;margin:5px 0}} .r span{{width:48px;color:var(--mut)}}
.r i{{display:block;height:14px;background:var(--acc);border-radius:4px;min-width:3px}}
ul{{list-style:none;padding:0;margin:0}} li{{display:flex;justify-content:space-between;padding:6px 0;border-bottom:1px solid var(--bg)}}
form{{margin:8px 0}} input{{padding:6px;border-radius:6px;border:1px solid var(--mut);background:var(--card);color:var(--ink)}}
</style><main>
<h1>{e(SHOP)}: monthly report</h1>
<form><input type=hidden name=key value="{e(request.args.get('key',''))}">
<input type=month name=month value="{e(rep['month'])}"> <button>View</button></form>
<div class=grid><div class=c><b>{rep['total']}</b><span>orders</span></div>
<div class=c><b>{rep['customers']}</b><span>customers</span></div>{statuses}</div>
<div class=card><h3>Orders per day</h3>{bars}</div>
<div class=card><h3>Delivery slots</h3><ul>{slots}</ul></div>
<div class=card><h3>Top customers</h3><ul>{top}</ul></div></main>"""


@app.get("/")
def health():
    return "WhatsApp order bot is running", 200


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.getenv("PORT", 5000)), debug=False)
