"""Offline simulation of the whole flow (no Meta account needed).

    python simulate.py
Uses a fake WhatsApp client that prints messages instead of sending them.
"""
import os
import tempfile

os.environ["DB_PATH"] = os.path.join(tempfile.mkdtemp(), "sim.db")
os.environ["SHOPKEEPER_PHONE"] = "919000000001"
os.environ["SHOP_NAME"] = "Fresh Mart"

import bot  # noqa: E402
import db  # noqa: E402

CUSTOMER, SHOPKEEPER = "919111111111", "919000000001"


class FakeWA:
    def _p(self, to, kind, body, extra=""):
        who = "SHOPKEEPER" if to == SHOPKEEPER else "CUSTOMER  "
        print(f"  -> {who} [{kind}] {body.replace(chr(10), ' / ')} {extra}")

    def send_text(self, to, text):
        self._p(to, "text", text)

    def send_buttons(self, to, body, buttons, **kw):
        self._p(to, "buttons", body, [t for _, t in buttons])

    def send_list(self, to, body, button_text, rows, **kw):
        self._p(to, "list", body, [t for _, t, _ in rows])

    def send_template(self, to, name, lang="en", body_params=None):
        self._p(to, "template", name)


def say(who, text=None, rid=None):
    print(f"\n{'CUSTOMER' if who == CUSTOMER else 'SHOPKEEPER'} says: {text or '[tap ' + rid + ']'}")
    bot.handle(FakeWA(), who, "Asha", text, rid)


db.init()
wa = FakeWA()
say(CUSTOMER, "hi")
say(CUSTOMER, rid="new_order")
say(CUSTOMER, "2 kg rice, 1 L milk, 6 eggs")
say(CUSTOMER, rid="day_tomorrow")
say(CUSTOMER, rid="slot_evening")
say(CUSTOMER, "12, Gandhi Street, near temple")
say(CUSTOMER, rid="confirm")
say(SHOPKEEPER, "orders")
say(SHOPKEEPER, rid="accept_1")
say(SHOPKEEPER, "done 1")
say(SHOPKEEPER, "report")

# a couple more orders so the web report has something to show
for i in range(2):
    db.create_order(f"9199999999{i}", f"Cust{i}", {"items": "bread", "date": "2026-11-01",
                                                   "slot": "Morning (9 AM - 12 PM)", "address": "x"})

# web report
client = bot.app.test_client()
print("\n/report without key ->", client.get("/report").status_code)
r = client.get(f"/report?key={os.getenv('ADMIN_KEY', 'None')}")
print("/report with key    ->", r.status_code)
os.environ["ADMIN_KEY"] = "k"
r = client.get("/report?key=k")
print("/report with ADMIN_KEY set ->", r.status_code, f"({len(r.data)} bytes of HTML)")
open("report_preview.html", "wb").write(r.data)

# webhook verification
os.environ["VERIFY_TOKEN"] = "tok"
print("webhook verify ok  ->", client.get("/webhook?hub.mode=subscribe&hub.verify_token=tok&hub.challenge=123").data)
print("webhook verify bad ->", client.get("/webhook?hub.mode=subscribe&hub.verify_token=no&hub.challenge=1").status_code)
